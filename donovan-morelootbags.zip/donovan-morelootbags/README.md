# Donovan MoreLootbags

## 7 Days 2 Die Modlet

Increases the drop rate on zombie loot bags: 5% for normal, 10% for feral, and 20% for irradiated.

Hint: Works well with [LongerLootbags](https://github.com/DonovanMods/donovan-7d2d-modlets/tree/master/donovan-longerlootbags) for those long horde nights.
